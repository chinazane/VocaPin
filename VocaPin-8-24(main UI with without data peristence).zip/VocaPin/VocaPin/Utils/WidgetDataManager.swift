//
//  WidgetDataManager.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/23/25.
//

import Foundation
import SwiftUI
import WidgetKit

class WidgetDataManager {
    static let shared = WidgetDataManager()
    private let userDefaults = UserDefaults(suiteName: "group.vocapin.notes")
    
    private init() {}
    
    func saveCurrentNote(_ note: Note) {
        let widgetNote = WidgetNote(
            text: note.text,
            color: note.color,
            rotation: note.rotation
        )
        
        if let encoded = try? JSONEncoder().encode(widgetNote) {
            userDefaults?.set(encoded, forKey: "currentNote")
            
            // Reload all widgets
            WidgetCenter.shared.reloadAllTimelines()
        }
    }
    
    func saveNotes(_ notes: [Note], currentIndex: Int) {
        // Save the current note for the widget
        if currentIndex < notes.count {
            saveCurrentNote(notes[currentIndex])
        }
        
        // Also save all notes for potential future use
        let widgetNotes = notes.map { note in
            WidgetNote(text: note.text, color: note.color, rotation: note.rotation)
        }
        
        if let encoded = try? JSONEncoder().encode(widgetNotes) {
            userDefaults?.set(encoded, forKey: "allNotes")
            userDefaults?.set(currentIndex, forKey: "currentNoteIndex")
        }
    }
}

// Widget-compatible Note structure
struct WidgetNote: Codable {
    let text: String
    let colorRed: Double
    let colorGreen: Double
    let colorBlue: Double
    let rotation: Double
    
    var color: Color {
        Color(red: colorRed, green: colorGreen, blue: colorBlue)
    }
    
    init(text: String, color: Color, rotation: Double = 0) {
        self.text = text
        self.rotation = rotation
        
        // Convert SwiftUI Color to RGB components
        let uiColor = UIColor(color)
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        
        uiColor.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        self.colorRed = Double(red)
        self.colorGreen = Double(green)
        self.colorBlue = Double(blue)
    }
}