//
//  VocaPinApp.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/22/25.
//

import SwiftUI

@main
struct VocaPinApp: App {
    var body: some Scene {
        WindowGroup {
            NotesView()
        }
    }
}
