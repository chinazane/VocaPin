//
//  StickyNoteView.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/22/25.
//

import SwiftUI

struct StickyNoteView: View {
    let note: Note
    let isEditing: Bool
    @Binding var editingText: String
    let onTap: () -> Void
    
    var body: some View {
        ZStack {
            // Main note shadow
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.black.opacity(0.15))
                .frame(width: 350, height: 350)
                .offset(x: 4, y: 4)
            
            // Main note (single layer)
            RoundedRectangle(cornerRadius: 12)
                .fill(note.color)
                .frame(width: 350, height: 350)
                .overlay(
                    // Note content
                    VStack {
                        Spacer()
                        
                        // Display mode - show Text
                        Text(note.text)
                            .font(.custom("Marker Felt", size: 36))
                            .foregroundColor(.black)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 30)
                            .onTapGesture {
                                onTap()
                            }
                        
                        Spacer()
                    }
                )
        }
        .overlay(
            // Red pin - positioned on top of everything
            VStack(spacing: 0) {
                // Pin head
                Circle()
                    .fill(Color.red)
                    .frame(width: 26, height: 26)
                    .overlay(
                        // Highlight
                        Circle()
                            .fill(Color.white.opacity(0.4))
                            .frame(width: 18, height: 18)
                            .offset(x: -3, y: -3)
                    )
                    .shadow(color: .black.opacity(0.4), radius: 3, x: 1, y: 1)
                
                // Pin needle
                Rectangle()
                    .fill(Color.red.opacity(0.9))
                    .frame(width: 4, height: 25)
                    .shadow(color: .black.opacity(0.2), radius: 1, x: 1, y: 0)
                
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            .offset(y: -13)
        )
        .rotationEffect(.degrees(note.rotation))
    }
}

#Preview {
    StickyNoteView(
        note: Note(text: "Sample Note\nPreview", position: CGPoint(x: 0, y: 0), rotation: -2),
        isEditing: false,
        editingText: .constant("Sample Note\nPreview"),
        onTap: {}
    )
}