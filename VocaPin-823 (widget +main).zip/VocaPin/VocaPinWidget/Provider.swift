//
//  Provider.swift
//  VocaPinWidget
//
//  Created by Bill Zhang on 8/22/25.
//

import WidgetKit
import SwiftUI

struct NoteProvider: TimelineProvider {
    func placeholder(in context: Context) -> NoteEntry {
        NoteEntry(date: Date(), note: SampleNote.sample)
    }

    func getSnapshot(in context: Context, completion: @escaping (NoteEntry) -> ()) {
        let entry = NoteEntry(date: Date(), note: SampleNote.sample)
        completion(entry)
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<NoteEntry>) -> ()) {
        var entries: [NoteEntry] = []

        // Get the current note from UserDefaults or use sample
        let currentNote = loadCurrentNote()
        
        // Generate a timeline consisting of one entry for now
        let currentDate = Date()
        let entry = NoteEntry(date: currentDate, note: currentNote)
        entries.append(entry)

        // Update timeline every hour
        let nextUpdate = Calendar.current.date(byAdding: .hour, value: 1, to: currentDate)!
        let timeline = Timeline(entries: entries, policy: .after(nextUpdate))
        completion(timeline)
    }
    
    private func loadCurrentNote() -> WidgetNote {
        // Try to load the current note from UserDefaults
        if let data = UserDefaults(suiteName: "group.vocapin.notes")?.data(forKey: "currentNote"),
           let note = try? JSONDecoder().decode(WidgetNote.self, from: data) {
            return note
        }
        
        // Return sample note if no saved note
        return SampleNote.sample
    }
}

struct NoteEntry: TimelineEntry {
    let date: Date
    let note: WidgetNote
}