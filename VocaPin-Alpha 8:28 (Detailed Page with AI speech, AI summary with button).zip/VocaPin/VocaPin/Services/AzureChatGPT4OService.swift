import Foundation

// MARK: - Models
struct ChatMessage: Codable {
    let role: String
    let content: String
}

struct ChatRequestBody: Codable {
    let messages: [ChatMessage]
    let temperature: Double
    let max_tokens: Int
    let response_format: ResponseFormat
    
    struct ResponseFormat: Codable {
        let type: String
    }
}

struct ChatJSONResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let role: String
            let content: String
        }
        let index: Int
        let finish_reason: String
        let message: Message
    }
    let id: String
    let model: String
    let choices: [Choice]
}

struct AzureAPIErrorEnvelope: Codable, Error {
    struct AzureError: Codable {
        let code: String
        let message: String
    }
    let error: AzureError
}

// MARK: - Service
/// A service class for Azure OpenAI GPT-4o chat completions
/// Usage:
///   let service = AzureChatGPT4OService(
///       config: .init(
///           endpoint: "https://your-resource.cognitiveservices.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2025-01-01-preview",
///           apiKey: "your-api-key",
///           defaultSystemPrompt: "You are a helpful assistant."
///       )
///   )
///   let response = try await service.chat(user: "Hello")
final class AzureChatGPT4OService {
    
    struct Config {
        /// Full chat completions URL, e.g.:
        /// https://<resource>.cognitiveservices.azure.com/openai/deployments/<deployment>/chat/completions?api-version=2025-01-01-preview
        let endpoint: String
        /// The `api-key` header value (NOT "Bearer ...")
        let apiKey: String
        /// Default system prompt for all requests (can be overridden per call)
        let defaultSystemPrompt: String
        
        /// Default configuration with preset values
        static let `default` = Config(
            endpoint: "https://aiazurebill.cognitiveservices.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2025-01-01-preview",
            apiKey: "24HI031OQ4NEzuIVm55VKhoeTnyhZnPC7zDG1c3vkiyZNmKdy6UTJQQJ99BGACYeBjFXJ3w3AAAAACOGWg6e",
            defaultSystemPrompt: stickyNoteSystemPrompt
        )
    }
    
      
    private let endpoint: URL
    private let apiKey: String
    private let defaultSystemPrompt: String
    private let session: URLSession
    
    init(config: Config = .default, session: URLSession = .shared) {
        guard let url = URL(string: config.endpoint) else {
            preconditionFailure("Invalid endpoint URL: \(config.endpoint)")
        }
        self.endpoint = url
        self.apiKey = config.apiKey
        self.defaultSystemPrompt = config.defaultSystemPrompt
        self.session = session
    }
    
    /// Convenience initializer with preset values
    static func createDefault(systemPrompt: String? = nil) -> AzureChatGPT4OService {
        let config = Config(
            endpoint: "https://china-mel64ynr-eastus2.cognitiveservices.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-03-01-preview",
            apiKey: "983oszCUT0BCErg6cCY2PqzFPB9hoUunlEMFpPcp1EfQF5FDbT4iJQQJ99BHACHYHv6XJ3w3AAAAACOGj1a5",
            defaultSystemPrompt: systemPrompt ?? stickyNoteSystemPrompt
        )
        return AzureChatGPT4OService(config: config)
    }
    
    /// Sends messages to Azure OpenAI and returns plain text if server honors `response_format: { type: "text" }`,
    /// otherwise extracts `choices[0].message.content` from JSON.
    ///
    /// - Parameters:
    ///   - user: User message content
    ///   - systemPrompt: Optional override for the default system prompt
    ///   - temperature: Sampling temperature (0.0 to 2.0)
    ///   - maxTokens: Maximum tokens to generate
    /// - Returns: The generated response text
    /// - Throws: Network or API errors
    func chat(
        user: String,
        systemPrompt: String? = nil,
        temperature: Double = 0.2,
        maxTokens: Int = 800
    ) async throws -> String {
        
        let body = ChatRequestBody(
            messages: [
                ChatMessage(role: "system", content: systemPrompt ?? defaultSystemPrompt),
                ChatMessage(role: "user", content: user)
            ],
            temperature: temperature,
            max_tokens: maxTokens,
            response_format: ChatRequestBody.ResponseFormat(type: "text")
        )
        
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "api-key")
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await session.data(for: request)
        
        // Handle response
        if let httpResponse = response as? HTTPURLResponse {
            let contentType = httpResponse.value(forHTTPHeaderField: "Content-Type")?.lowercased() ?? ""
            
            // If server returned plain text, prefer it
            if contentType.contains("text/plain") || contentType.contains("text/event-stream") {
                return String(data: data, encoding: .utf8) ?? ""
            }
            
            // Handle error responses
            if httpResponse.statusCode >= 400 {
                if let errorEnvelope = try? JSONDecoder().decode(AzureAPIErrorEnvelope.self, from: data) {
                    throw AzureChatGPT4OError.apiError(
                        code: errorEnvelope.error.code,
                        message: errorEnvelope.error.message
                    )
                }
                throw AzureChatGPT4OError.httpError(statusCode: httpResponse.statusCode)
            }
        }
        
        // Try to decode as JSON response
        do {
            let decoded = try JSONDecoder().decode(ChatJSONResponse.self, from: data)
            guard let content = decoded.choices.first?.message.content, !content.isEmpty else {
                throw AzureChatGPT4OError.emptyResponse
            }
            return content
        } catch {
            // If JSON decoding fails, try to return raw text
            if let rawText = String(data: data, encoding: .utf8), !rawText.isEmpty {
                return rawText
            }
            throw AzureChatGPT4OError.decodingError(error)
        }
    }
    
    /// Convenience method for multiple message conversations
    /// - Parameters:
    ///   - messages: Array of chat messages
    ///   - temperature: Sampling temperature
    ///   - maxTokens: Maximum tokens to generate
    /// - Returns: The generated response text
    func chat(
        messages: [ChatMessage],
        temperature: Double = 0.2,
        maxTokens: Int = 800
    ) async throws -> String {
        
        let body = ChatRequestBody(
            messages: messages,
            temperature: temperature,
            max_tokens: maxTokens,
            response_format: ChatRequestBody.ResponseFormat(type: "text")
        )
        
        var request = URLRequest(url: endpoint)
        request.httpMethod = "POST"
        request.timeoutInterval = 60
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(apiKey, forHTTPHeaderField: "api-key")
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await session.data(for: request)
        
        // Handle response (same logic as above)
        if let httpResponse = response as? HTTPURLResponse {
            let contentType = httpResponse.value(forHTTPHeaderField: "Content-Type")?.lowercased() ?? ""
            
            if contentType.contains("text/plain") || contentType.contains("text/event-stream") {
                return String(data: data, encoding: .utf8) ?? ""
            }
            
            if httpResponse.statusCode >= 400 {
                if let errorEnvelope = try? JSONDecoder().decode(AzureAPIErrorEnvelope.self, from: data) {
                    throw AzureChatGPT4OError.apiError(
                        code: errorEnvelope.error.code,
                        message: errorEnvelope.error.message
                    )
                }
                throw AzureChatGPT4OError.httpError(statusCode: httpResponse.statusCode)
            }
        }
        
        do {
            let decoded = try JSONDecoder().decode(ChatJSONResponse.self, from: data)
            guard let content = decoded.choices.first?.message.content, !content.isEmpty else {
                throw AzureChatGPT4OError.emptyResponse
            }
            return content
        } catch {
            if let rawText = String(data: data, encoding: .utf8), !rawText.isEmpty {
                return rawText
            }
            throw AzureChatGPT4OError.decodingError(error)
        }
    }
}

// MARK: - Error Types
enum AzureChatGPT4OError: Error, LocalizedError {
    case apiError(code: String, message: String)
    case httpError(statusCode: Int)
    case emptyResponse
    case decodingError(Error)
    case invalidConfiguration
    
    var errorDescription: String? {
        switch self {
        case .apiError(let code, let message):
            return "Azure API Error [\(code)]: \(message)"
        case .httpError(let statusCode):
            return "HTTP Error: \(statusCode)"
        case .emptyResponse:
            return "Empty response from Azure OpenAI"
        case .decodingError(let error):
            return "Failed to decode response: \(error.localizedDescription)"
        case .invalidConfiguration:
            return "Invalid service configuration"
        }
    }
}

// MARK: - Predefined System Prompts
extension AzureChatGPT4OService {
    
    static let stickyNoteSystemPrompt = """
    [Role]
    You are an AI productivity assistant that transforms raw transcripts, meeting notes, or free-form speech into clear and concise sticky notes.

    [Key Purpose]
    Generate short, structured sticky notes that highlight the most important actions, decisions, and reminders.
    Pls note that always keep the output in the same language as the input text. Do not translate.

    [Instructions]
        •    Detect the original language of the input.
        •    Output sticky notes in that same language.
        •    Extract only key points (task, deadline, time, people, place, decision).
        •    Keep each note under 20 words, simple and scannable.
        •    Format notes consistently:
    
    """
    
    static let generalAssistantPrompt = """
    You are a helpful, knowledgeable, and friendly AI assistant. Provide clear, accurate, and concise responses to user questions and requests.
    """
    
    static let noteEnhancementPrompt = """
    You are a helpful assistant that improves and enhances note content. Make the text clearer, more organized, and easier to understand while maintaining the original meaning and intent.
    """
}

// MARK: - Usage Examples
/*
// Example 1: Simplest usage with preset values
let service = AzureChatGPT4OService()
let response = try await service.chat(user: "Hello, how are you?")
print(response)

// Example 2: Using preset values with custom system prompt
let stickyNoteService = AzureChatGPT4OService.createDefault(
    systemPrompt: AzureChatGPT4OService.stickyNoteSystemPrompt
)
let transcript = "明天上午10点要给Sarah发邮件，下午要review项目slides"
let stickyNotes = try await stickyNoteService.chat(user: transcript)
print(stickyNotes)

// Example 3: Using default config
let defaultService = AzureChatGPT4OService(config: .default)
let defaultResponse = try await defaultService.chat(user: "What can you help me with?")
print(defaultResponse)

// Example 4: Multi-message conversation
let messages = [
    ChatMessage(role: "system", content: "You are a helpful assistant."),
    ChatMessage(role: "user", content: "What's the weather like?"),
    ChatMessage(role: "assistant", content: "I don't have access to current weather data."),
    ChatMessage(role: "user", content: "Can you help me with something else?")
]
let conversationResponse = try await service.chat(messages: messages)
print(conversationResponse)

// Example 5: Custom configuration (if needed)
let customService = AzureChatGPT4OService(
    config: .init(
        endpoint: "https://custom-endpoint.com/...",
        apiKey: "custom-api-key",
        defaultSystemPrompt: "Custom system prompt"
    )
)
*/
