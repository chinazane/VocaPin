//
//  NotebookEditingView.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/22/25.
//

import SwiftUI
import WidgetKit

struct NotebookEditingView: View {
    @Binding var isPresented: Bool
    @Binding var note: Note
    @State private var editingText: String = ""
    @FocusState private var isTextEditorFocused: Bool
    
    // AI Summary states
    @State private var isProcessingAI = false
    @State private var aiSummaryError: String?
    @State private var showingAIError = false
    
    // Footer action states
    @State private var showSpeechRecognition = false
    @State private var showDeleteConfirmation = false
    
    // AI Service
    private let aiService = AzureChatGPT4OService()
    
    var body: some View {
        NavigationView {
            ZStack {
                // Cork board background
                Color(red: 0.9, green: 0.85, blue: 0.8)
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // Navigation bar
                    HStack {
                        Button("Cancel") {
                            isPresented = false
                        }
                        .foregroundColor(.red)
                        .fontWeight(.medium)
                        
                        Spacer()
                        
                        Text("Edit Note")
                            .font(.title3)
                            .fontWeight(.semibold)
                            .foregroundColor(.black)
                        
                        Spacer()
                        
                        Button("Done") {
                            note.text = editingText
                            // Force immediate widget sync when note is edited
                            WidgetCenter.shared.reloadAllTimelines()
                            isPresented = false
                        }
                        .foregroundColor(.blue)
                        .fontWeight(.semibold)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    .padding(.bottom, 10)
                    
                    // AI Summary toolbar
                    HStack {
                        Button(action: generateAISummary) {
                            HStack(spacing: 8) {
                                if isProcessingAI {
                                    ProgressView()
                                        .scaleEffect(0.8)
                                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                } else {
                                    Image(systemName: "sparkles")
                                        .font(.system(size: 16, weight: .medium))
                                }
                                Text(isProcessingAI ? "Processing..." : "AI Summary")
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                            }
                            .foregroundColor(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                            .background(
                                LinearGradient(
                                    colors: [Color.purple, Color.blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(20)
                        }
                        .disabled(isProcessingAI || editingText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        
                        Spacer()
                        
                        // Status indicator
                        if isProcessingAI {
                            Text("Generating summary...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        } else if !editingText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            Text("Ready for AI processing")
                                .font(.caption)
                                .foregroundColor(.green)
                        } else {
                            Text("Enter text to summarize")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 15)
                    
                    // Large sticky note for editing
                    ZStack {
                        // Note shadow
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color.black.opacity(0.15))
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .offset(x: 6, y: 6)
                        
                        // Main note
                        RoundedRectangle(cornerRadius: 16)
                            .fill(note.color)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .overlay(
                                VStack {
                                    Spacer()
                                    
                                    // Text editor
                                    TextEditor(text: $editingText)
                                        .font(.custom("Marker Felt", size: 28))
                                        .foregroundColor(.black)
                                        .multilineTextAlignment(.leading)
                                        .padding(.horizontal, 30)
                                        .padding(.vertical, 20)
                                        .background(Color.clear)
                                        .scrollContentBackground(.hidden)
                                        .focused($isTextEditorFocused)
                                    
                                    Spacer()
                                }
                            )
                    }
                    .overlay(
                        // Red pin (head only, no needle)
                        VStack {
                            Circle()
                                .fill(Color.red)
                                .frame(width: 32, height: 32)
                                .overlay(
                                    Circle()
                                        .fill(Color.white.opacity(0.4))
                                        .frame(width: 22, height: 22)
                                        .offset(x: -4, y: -4)
                                )
                                .shadow(color: .black.opacity(0.4), radius: 4, x: 2, y: 2)
                            
                            Spacer()
                        }
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
                        .offset(y: -16)
                    )
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                    
                    // Footer action buttons
                    FooterActionButtonsView(
                        showSpeechRecognition: $showSpeechRecognition,
                        showDeleteConfirmation: $showDeleteConfirmation,
                        isTextEditorFocused: isTextEditorFocused,
                        onEditTapped: {
                            isTextEditorFocused = true
                        }
                    )
                }
            }
        }
        .navigationBarHidden(true)
        .onAppear {
            editingText = note.text
            // Do not auto-focus - let user tap Edit button to activate keyboard
        }
        .alert("AI Summary Error", isPresented: $showingAIError) {
            Button("OK") { }
        } message: {
            Text(aiSummaryError ?? "An unknown error occurred")
        }
        .sheet(isPresented: $showSpeechRecognition) {
            SpeechRecognitionView(isPresented: $showSpeechRecognition) { recognizedText in
                // Append the recognized text to the current editing text
                if !recognizedText.isEmpty {
                    DispatchQueue.main.async {
                        if editingText.isEmpty {
                            editingText = recognizedText
                        } else {
                            editingText += " " + recognizedText
                        }
                        
                        // Ensure the text editor is focused after adding text
                        isTextEditorFocused = true
                    }
                }
            }
        }
        .alert("Clear Note Content", isPresented: $showDeleteConfirmation) {
            Button("Cancel", role: .cancel) { }
            Button("Clear", role: .destructive) {
                clearNoteContent()
            }
        } message: {
            Text("Are you sure you want to clear this note? This action cannot be undone.")
        }
    }
    
    // MARK: - AI Summary Functions
    
    private func generateAISummary() {
        guard !editingText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            aiSummaryError = "Please enter some text to summarize"
            showingAIError = true
            return
        }
        
        isProcessingAI = true
        
        Task {
            do {
                print("🤖 AI Summary: Starting processing for text: '\(editingText.prefix(50))...'")
                
                let aiResponse = try await aiService.chat(user: editingText)
                
                await MainActor.run {
                    self.isProcessingAI = false
                    
                    // Log the AI response to console as requested
                    print("✨ AI Summary Response:")
                    print("=" * 50)
                    print(aiResponse)
                    print("=" * 50)
                    
                    // Optional: You could also show a success message or update the UI
                    print("🎉 AI Summary completed successfully!")
                }
                
            } catch {
                await MainActor.run {
                    self.isProcessingAI = false
                    self.aiSummaryError = "Failed to generate AI summary: \(error.localizedDescription)"
                    self.showingAIError = true
                    
                    print("❌ AI Summary Error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    // MARK: - Delete Functions
    
    private func clearNoteContent() {
        editingText = ""
        note.text = ""
        // Force immediate widget sync when note is cleared
        WidgetCenter.shared.reloadAllTimelines()
    }
}

// MARK: - Helper Extension
private extension String {
    static func * (left: String, right: Int) -> String {
        return String(repeating: left, count: right)
    }
}

#Preview {
    NotebookEditingView(
        isPresented: .constant(true),
        note: .constant(Note(text: "Sample note text\nfor editing", position: CGPoint(x: 0, y: 0), rotation: 0))
    )
}
