//
//  Note.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/22/25.
//

import Foundation

import SwiftUI

struct Note: Identifiable {
    let id = UUID()
    var text: String
    var position: CGPoint
    var rotation: Double
    var color: Color = .yellow
}