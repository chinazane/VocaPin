//
//  ContentView.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/22/25.
//

import SwiftUI

struct NotesView: View {
    @State private var notes: [Note] = [
        Note(text: "Meeting with Alex\nat 3 PM.", position: CGPoint(x: 0, y: 0), rotation: -2),
        Note(text: "Buy groceries\n- Milk\n- Bread\n- Eggs", position: CGPoint(x: 0, y: 0), rotation: 1.5),
        Note(text: "Call Mom\nat 7 PM", position: CGPoint(x: 0, y: 0), rotation: -1),
        Note(text: "Finish project\ndeadline Friday", position: CGPoint(x: 0, y: 0), rotation: 0.5),
        Note(text: "Doctor appointment\nTuesday 2 PM", position: CGPoint(x: 0, y: 0), rotation: -1.5),
        Note(text: "Weekend plans\n- Beach trip\n- BBQ party", position: CGPoint(x: 0, y: 0), rotation: 2)
    ]
    @State private var currentPage = 0
    @State private var dragOffset: CGFloat = 0
    @State private var isDragging = false
    @State private var showColorSettings = false
    @State private var selectedNoteColor: Color = .yellow
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Cork board background
                CorkBoardBackground()
                
                VStack(spacing: 0) {
                    // Header
                    HeaderView()
                    
                    Spacer()
                    
                    // Notes area with swipe functionality
                    ZStack {
                        ForEach(Array(notes.enumerated()), id: \.element.id) { index, note in
                            StickyNoteView(note: note)
                                .position(
                                    x: geometry.size.width / 2 + note.position.x,
                                    y: geometry.size.height / 2 + note.position.y - 80
                                )
                                .offset(x: CGFloat(index - currentPage) * geometry.size.width + dragOffset)
                                .scaleEffect(index == currentPage ? 1.0 : 0.8)
                                .opacity(index == currentPage ? 1.0 : 0.3)
                                .animation(.spring(response: 0.6, dampingFraction: 0.8), value: currentPage)
                                .animation(.interactiveSpring(), value: dragOffset)
                        }
                    }
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                isDragging = true
                                dragOffset = value.translation.width
                            }
                            .onEnded { value in
                                isDragging = false
                                let threshold: CGFloat = 100
                                
                                withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                                    if value.translation.width > threshold && currentPage > 0 {
                                        // Swipe right - go to previous note
                                        currentPage -= 1
                                    } else if value.translation.width < -threshold && currentPage < notes.count - 1 {
                                        // Swipe left - go to next note
                                        currentPage += 1
                                    }
                                    dragOffset = 0
                                }
                            }
                    )
                    
                    Spacer()
                    
                    // Page indicators
                    PageIndicatorView(currentPage: currentPage, totalPages: notes.count)
                        .padding(.bottom, 20)
                    
                    // Bottom toolbar
                    BottomToolbarView(showColorSettings: $showColorSettings)
                }
            }
        }
        .ignoresSafeArea(.all, edges: .bottom)
        .fullScreenCover(isPresented: $showColorSettings) {
            NoteColorSettingsView(
                isPresented: $showColorSettings,
                selectedColor: $selectedNoteColor
            )
        }
        .onChange(of: selectedNoteColor) { newColor in
            // Update current note's color when color is selected
            if currentPage < notes.count {
                notes[currentPage].color = newColor
            }
        }
    }
}



#Preview {
    NotesView()
}
