//
//  SettingRow.swift
//  VocaPin
//
//  Created by Bill Zhang on 8/27/25.
//

import SwiftUI

enum SettingAction {
    case toggle(Binding<Bool>)
    case navigation(() -> Void)
}

struct SettingRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let action: SettingAction
    
    var body: some View {
        HStack(spacing: 16) {
            // Icon
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(.gray)
                .frame(width: 24, height: 24)
                .accessibilityHidden(true)
            
            // Content
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.body)
                    .fontWeight(.medium)
                    .foregroundColor(.black)
                
                Text(subtitle)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            // Action
            switch action {
            case .toggle(let binding):
                Toggle("", isOn: binding)
                    .labelsHidden()
                    .accessibilityLabel("\(title) toggle")
                    .accessibilityValue(binding.wrappedValue ? "On" : "Off")
                
            case .navigation(let handler):
                Button(action: handler) {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(.gray)
                }
                .accessibilityLabel("Navigate to \(title)")
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
        .accessibilityElement(children: .combine)
        .accessibilityLabel("\(title). \(subtitle)")
    }
}

#Preview {
    VStack(spacing: 16) {
        SettingRow(
            icon: "widget.small",
            title: "Add Homepage Widget",
            subtitle: "Quick access from your home screen.",
            action: .toggle(.constant(true))
        )
        
        SettingRow(
            icon: "globe",
            title: "Language",
            subtitle: "English",
            action: .navigation({})
        )
    }
    .padding()
    .background(Color(red: 0.9, green: 0.85, blue: 0.8))
}