//
//  ProfileSettingsView.swift
//  VocaPin
//
//  Created by Kiro on 8/27/25.
//

import SwiftUI
import WidgetKit
import StoreKit
import WebKit

struct ProfileSettingsView: View {
    @StateObject private var settingsManager = SettingsManager.shared
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 24) {
                    // Header Section
                    HeaderSection()
                    
                    // Premium Section
                    PremiumSection()
                    
                    // Settings Section
                    SettingsSection()
                    
                    // Footer Section
                    FooterSection()
                    
                    Spacer(minLength: 50)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
            }
            .background(Color(red: 0.9, green: 0.85, blue: 0.8))
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .medium))
                            Text("Back")
                                .font(.body)
                        }
                        .foregroundColor(.black)
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

// MARK: - Header Section
private struct HeaderSection: View {
    var body: some View {
        VStack(spacing: 12) {
            // App Logo
            Image("AppLogo")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 60, height: 60)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
            
            // App Title
            Text("Vocal Sticky")
                .font(.title2)
                .fontWeight(.medium)
                .foregroundColor(.black)
            
            // Tagline
            Text("Speak it. Stick it.")
                .font(.caption)
                .foregroundColor(.gray)
        }
        .padding(.vertical, 8)
    }
}

// MARK: - Settings Section
private struct SettingsSection: View {
    @StateObject private var settingsManager = SettingsManager.shared
    @State private var showWidgetGuidance = false
    private let ratingService: RatingServiceProtocol = RatingService.shared
    
    var body: some View {
        VStack(spacing: 16) {
            SettingRow(
                icon: "widget.small",
                title: "Add Homepage Widget",
                subtitle: "Quick access from your home screen.",
                action: .toggle($settingsManager.isWidgetEnabled)
            )
            .onChange(of: settingsManager.isWidgetEnabled) { _, newValue in
                handleWidgetToggle(enabled: newValue)
            }
            
            SettingRow(
                icon: "globe",
                title: "Language",
                subtitle: settingsManager.getCurrentSystemLanguage(),
                action: .navigation {
                    handleLanguageSettings()
                }
            )
            
            SettingRow(
                icon: "star.fill",
                title: "Rate the App",
                subtitle: "Share your feedback on the App Store.",
                action: .navigation {
                    handleRateApp()
                }
            )
        }
        .alert("Widget Setup", isPresented: $showWidgetGuidance) {
            Button("OK") { }
        } message: {
            Text(settingsManager.getWidgetSetupGuidance())
        }
    }
    
    private func handleWidgetToggle(enabled: Bool) {
        // Configure widget based on new state
        settingsManager.configureWidget()
        
        // Show guidance when widget is enabled
        if enabled {
            showWidgetGuidance = true
        }
    }
    
    private func handleLanguageSettings() {
        // Open iOS Settings app to language settings
        settingsManager.openLanguageSettings()
    }
    
    private func handleRateApp() {
        // Use RatingService to handle the rating request
        ratingService.requestRating()
    }
}

// MARK: - Premium Section
private struct PremiumSection: View {
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 12) {
                // Lock Icon
                Image(systemName: "lock.fill")
                    .font(.system(size: 24, weight: .medium))
                    .foregroundColor(.white)
                
                VStack(alignment: .leading, spacing: 4) {
                    // Title
                    Text("Unlock Premium")
                        .font(.body)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                    
                    // Description
                    Text("Unlimited notes & exclusive features")
                        .font(.caption)
                        .foregroundColor(.white.opacity(0.9))
                }
                
                Spacer()
            }
            
            // Upgrade Button
            Button(action: {
                handleUpgradeAction()
            }) {
                Text("Upgrade")
                    .font(.body)
                    .fontWeight(.medium)
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                    .shadow(color: .black.opacity(0.2), radius: 3, x: 0, y: 2)
            }
        }
        .padding(16)
        .background(
            LinearGradient(
                colors: [Color.yellow, Color.orange],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.1), radius: 2, x: 0, y: 1)
    }
    
    private func handleUpgradeAction() {
        // TODO: Implement premium upgrade flow
        // This will be connected to the app's premium subscription system
        print("Upgrade button tapped - Premium flow to be implemented")
    }
}

// MARK: - Footer Section
private struct FooterSection: View {
    @StateObject private var settingsManager = SettingsManager.shared
    @State private var showPrivacyPolicy = false
    @State private var showTermsOfService = false
    
    var body: some View {
        VStack(spacing: 16) {
            // App Version
            Text(settingsManager.getFormattedVersion())
                .font(.caption2)
                .foregroundColor(.gray)
            
            // Legal Links
            HStack(spacing: 8) {
                Button(action: {
                    showPrivacyPolicy = true
                }) {
                    Text("Privacy Policy")
                        .font(.caption2)
                        .foregroundColor(.gray)
                        .underline()
                }
                .accessibilityLabel("Privacy Policy")
                .accessibilityHint("Opens privacy policy in web browser")
                
                Text("·")
                    .font(.caption2)
                    .foregroundColor(.gray)
                
                Button(action: {
                    showTermsOfService = true
                }) {
                    Text("Terms of Service")
                        .font(.caption2)
                        .foregroundColor(.gray)
                        .underline()
                }
                .accessibilityLabel("Terms of Service")
                .accessibilityHint("Opens terms of service in web browser")
            }
        }
        .padding(.vertical, 16)
        .sheet(isPresented: $showPrivacyPolicy) {
            WebView(url: URL(string: "https://vocapin.com/privacy-policy")!)
                .navigationTitle("Privacy Policy")
                .navigationBarTitleDisplayMode(.inline)
        }
        .sheet(isPresented: $showTermsOfService) {
            WebView(url: URL(string: "https://vocapin.com/terms-of-service")!)
                .navigationTitle("Terms of Service")
                .navigationBarTitleDisplayMode(.inline)
        }
    }
}

// MARK: - Web View
private struct WebView: UIViewRepresentable {
    let url: URL
    
    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.navigationDelegate = context.coordinator
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        webView.load(request)
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate {
        let parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            // Handle navigation errors - fallback to external browser
            let url = webView.url ?? parent.url
            UIApplication.shared.open(url)
        }
    }
}

#Preview {
    ProfileSettingsView()
}